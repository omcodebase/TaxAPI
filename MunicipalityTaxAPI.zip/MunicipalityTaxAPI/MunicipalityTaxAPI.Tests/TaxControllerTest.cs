using Xunit;
using FakeItEasy;
using MunicipalityTaxAPI.Controllers;
using MunicipalityTaxAPI.Service;
using MunicipalityTaxAPI.Dto;
using MunicipalityTaxAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace MunicipalityTaxAPI.Tests
{
    public class TaxControllerTest
    {
        [Fact]
        public void GetTaxResults_Returns_Correct_Number_Of_TaxRules()
        {
            int count = 1;
            DateTime testdate = DateTime.Now;
            var dummyTaxResults = A.CollectionOfDummy<TaxResultsDto>(count).AsEnumerable().Take(1);
            var dataService = A.Fake<ITaxService>();
            A.CallTo(() => dataService.GetTaxResult("Vilnius", testdate)).Return(Task.FromResult(dummyTaxResults));
            var controller = new TaxController(dataService);

            var actionResult = controller.GetTaxResult("Vilnius", testdate);

            var result = actionResult.Result as OkObjectResult; 

            var returnTaxResults = result.Value as IEnumerable<TaxResultsDto>;

            Assert.Equal(count, returnTaxResults.Count());

        }
    }
}