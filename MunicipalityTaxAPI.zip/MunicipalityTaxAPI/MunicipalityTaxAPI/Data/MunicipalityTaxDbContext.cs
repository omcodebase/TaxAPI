﻿using Microsoft.EntityFrameworkCore;
using MunicipalityTaxAPI.Models;

namespace MunicipalityTaxAPI.Data
{
    public class MunicipalityTaxDbContext : DbContext
    {
        public MunicipalityTaxDbContext(DbContextOptions<MunicipalityTaxDbContext> options)
            : base(options)
        {

        }

        public DbSet<Municipality> Municipality { get; set; }
        public DbSet<TaxRule> TaxRule { get; set; }

    }
}

