﻿namespace MunicipalityTaxAPI.Dto
{
    public class TaxResultsDto
    {
        public string MunicipalityName { get; set; }

        public DateTime GivenDate { get; set; }

        public int TaxRuleType { get; set; }

        public decimal TaxResult { get; set; }
    }
}
