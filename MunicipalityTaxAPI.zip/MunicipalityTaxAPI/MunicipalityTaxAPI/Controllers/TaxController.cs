﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MunicipalityTaxAPI.Dto;
using MunicipalityTaxAPI.Models;
using MunicipalityTaxAPI.Service;

namespace MunicipalityTaxAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TaxController : ControllerBase
    {

        private readonly ITaxService _service;
        public TaxController(ITaxService service) => _service = service;

        [HttpGet("id")]
        [ProducesResponseType(typeof(TaxRule), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(int Id)
        {
            var taxPeriod = await _service.Get(Id);
            return taxPeriod == null ? NotFound() : Ok(taxPeriod);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> Create(TaxRule TaxPeriod)
        {
            var result = await _service.Create(TaxPeriod);

            return CreatedAtAction(nameof(GetById), new { });
        }

        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Update(int id, int TaxRuleType, string TaxPeriod,
            TaxRule taxRule)
        {
            if (id != taxRule.ID || TaxRuleType != taxRule.RuleType || TaxPeriod != taxRule.Period) return BadRequest();

            var result = await _service.Update(taxRule);
            

            return NoContent();


        }


        [HttpGet]
        public TaxResultsDto GetTaxResult(string municipalityName, DateTime TaxDate)
        {
            var taxResult = _service.GetTaxResult(municipalityName, TaxDate);

            return taxResult;
        }



    }
}
