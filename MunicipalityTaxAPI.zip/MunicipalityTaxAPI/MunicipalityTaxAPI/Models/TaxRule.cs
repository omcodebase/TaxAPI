﻿namespace MunicipalityTaxAPI.Models
{
    public class TaxRule
    {
        public int ID { get; set; }
        public int RuleType { get; set; }
        public string Period { get; set; }
        public decimal? Percentage { get; set; }

        public DateTime? InitialDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}
