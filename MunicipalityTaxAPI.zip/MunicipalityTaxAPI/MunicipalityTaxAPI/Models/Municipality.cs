﻿namespace MunicipalityTaxAPI.Models
{
    public class Municipality
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int RuleType { get; set; }
    }
}
