﻿using MunicipalityTaxAPI.Repository;
using MunicipalityTaxAPI.Models;
using MunicipalityTaxAPI.Dto;

namespace MunicipalityTaxAPI.Service
{
    public class TaxService : ITaxService
    {
        private readonly ITaxRepository _repository;

        public TaxService(ITaxRepository repository)
        {
            _repository = repository;
        }
        public async Task<TaxRule> Get(int ID)
        {
            var taxRules = await _repository.Get(ID); 
            return taxRules;
        }


        public async Task<bool> Create(TaxRule taxRule)
        {
            return await _repository.Create(taxRule);
        }


        public async Task<bool> Update(TaxRule taxRule)
        {
            return await _repository.Update(taxRule);
        }

        public TaxResultsDto GetTaxResult(string municipalityName, DateTime inputDate)
        {
            var taxResults = _repository.GetTaxResult(municipalityName, inputDate);

            return taxResults;

        }



        }
}
