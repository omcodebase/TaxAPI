﻿using MunicipalityTaxAPI.Dto;
using MunicipalityTaxAPI.Models;

namespace MunicipalityTaxAPI.Service
{
    public interface ITaxService
    {
        Task<TaxRule> Get(int ID);

        Task<bool> Create(TaxRule taxRule);

        Task<bool> Update(TaxRule taxRule);

        TaxResultsDto GetTaxResult(string municipalityName, DateTime inputDate);

    }
}
