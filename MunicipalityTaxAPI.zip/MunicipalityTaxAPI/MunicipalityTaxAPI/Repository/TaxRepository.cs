﻿using Microsoft.AspNetCore.Mvc;
using MunicipalityTaxAPI.Data;
using MunicipalityTaxAPI.Models;
using Microsoft.EntityFrameworkCore;
using MunicipalityTaxAPI.Dto;

namespace MunicipalityTaxAPI.Repository
{
    public class TaxRepository : ITaxRepository
    {
        private readonly MunicipalityTaxDbContext _context;
        public TaxRepository(MunicipalityTaxDbContext context) => _context = context;
        public async Task<TaxRule> Get(int ID)
        {
           var data = await _context.TaxRule.FindAsync(ID);
            return data;
         }


        public async Task<bool> Create(TaxRule taxRule)
        {
            try
            {
                await _context.TaxRule.AddAsync(taxRule);
                await _context.SaveChangesAsync();

                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }


        public async Task<bool> Update(TaxRule taxRule)
        {
            try
            {

                _context.Entry(taxRule).State = EntityState.Modified;

                await _context.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public TaxResultsDto GetTaxResult(string municipalityName, DateTime inputDate)
        {
            var municipality = _context.Municipality.Where(o => o.Name.Equals(municipalityName)).FirstOrDefault(); 

            var taxResults = _context.TaxRule.Where(o => o.RuleType == municipality.RuleType 
                                                         && !o.Period.ToUpper().Equals("DAILY")
                                                         && o.InitialDate <= inputDate 
                                                         && o.EndDate >= inputDate).Select(o => o.Percentage).ToList();


            var taxResultsDaily = _context.TaxRule.Where(o => o.RuleType == municipality.RuleType
                                                         && o.Period.ToUpper().Equals("DAILY")
                                                         && (o.InitialDate == inputDate
                                                         || o.EndDate == inputDate)).Select(o => o.Percentage).ToList();


            var taxresultsDTO = new TaxResultsDto();

            taxresultsDTO.MunicipalityName = municipalityName;
            taxresultsDTO.GivenDate = inputDate;
            taxresultsDTO.TaxRuleType = municipality.RuleType;
            taxresultsDTO.TaxResult = taxResults.Sum(x => Convert.ToDecimal(x)) + taxResultsDaily.Sum(x => Convert.ToDecimal(x));

            return taxresultsDTO;


        }


    }
}
